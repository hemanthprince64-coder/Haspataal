# Integrations

## Database
- **Primary DB:** Managed via Prisma (likely PostgreSQL or SQLite based on schema, to be confirmed).

## Authentication
- *Pending analysis of `lib/auth.js` or similar.*

## External APIs
- *None visible in `package.json` dependencies (e.g., no Stripe, SendGrid SDKs yet).*
